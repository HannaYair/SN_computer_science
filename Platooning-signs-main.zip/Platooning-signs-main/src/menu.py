import logging
import traci
import random
import threading
from src.sign import Sign,laneSign,platoonSign,vehicleSign
class Menue():

    def __init__(self):
        self.__work = True
        self.__mainInput = "\0"
        self.__middleInput = "\0"
        self.__lastInput = "\0"
        self.__finalInput = "\0"

    def resetGlobals(self):
        self.__work = True
        self.__mainInput = "\0"
        self.__middleInput = "\0"
        self.__lastInput = "\0"
        self.__finalInput = "\0"

    def getInput(self):
        print("press 1 for create platoon:\n"
              "press 2 for add traffic sign:\n"
              "press 3 for get platoon leader instruction\n")
        self.__mainInput = int(input("enter your choice:\n"))
        if self.__mainInput == 1:
            self.__middleInput = input("enter vehicle name:\n")
            self.__lastInput = "nothing"
            self.__finalInput = "nothing"
        elif self.__mainInput == 2:
            print("press 1 for Follow the first vehicle in a platoon:\n"
                  "press 2.1 for Dynamic vehicle/platoon distance restriction and 2.2 for cancel:\n"
                  "press 3.1 for Integration sign and 3.2 for cancel\n"
                  "press 4.1 for No entry for platoon/specific vehicle type and 4.2 for Open entry sign\n"
                  "press 5.1 for Limitation of lane speed for platoon and 5.2 for cancel:\n"
                  "press 6 for Limitation of lane speed:\n"
                  "press 7.1 for Limitation speed of vehicle/platoon and 7.2 for cancel\n"
                  "press 8 for Limitation of lane number of vehicles:\n"
                  "press 9 for Follow the behavior first vehicle in a platoon:\n")
            self.__middleInput = float(input("enter your choice:\n"))
            if self.__middleInput == 1:
                self.__lastInput = input("enter representative name\n")
                self.__finalInput = "nothing"
            elif self.__middleInput == 2.1:
                self.__lastInput = input("enter representative name\n")
                #TODO maybe to change the value of  safe distance to something dependings of speed
                self.__finalInput = input("enter safe distance:\n")
            elif self.__middleInput == 2.2:
                self.__lastInput = input("enter representative name\n")
                self.__finalInput = "nothing"
            elif self.__middleInput==3.1:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = float(input("enter safe distance:\n"))
            elif self.__middleInput==3.2:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput="nothing"
            elif (self.__middleInput==4.1)or(self.__middleInput==4.2):
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = input("enter types for block\n")
            elif self.__middleInput==5.1:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = float(input("enter speed\n"))
            elif self.__middleInput == 5.2:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = "nothing"
            elif self.__middleInput == 6:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = float(input("enter speed\n"))
            elif self.__middleInput==7.1:
                self.__lastInput = input("enter representative name\n")
                self.__finalInput = float(input("enter speed\n"))
            elif self.__middleInput == 7.2:
                self.__lastInput = input("enter representative name\n")
                self.__finalInput = "nothing"
            elif self.__middleInput == 8:
                self.__lastInput = input("enter lane number\n")
                self.__finalInput = float(input("enter number of vehicles\n"))
            elif self.__middleInput == 9:
                self.__lastInput = input("enter representative name\n")
                self.__finalInput = "nothing"
            else:
                self.__lastInput="nothing"
                self.__finalInput = "nothing"
        elif self.__mainInput == 3:
            self.__middleInput = input("enter platoon name:\n")
            self.__lastInput = int(input("enter instruction 1 for change the speed 2 for change lane\n"))
            if(self.__lastInput==1):
                self.__finalInput = float(input("enter speed"))
            elif(self.__lastInput==2):
                self.__finalInput = input("enter lane name")
        else:
            self.__lastInput = "nothing"
            self.__finalInput = "nothing"

    def run(self,manager):
        if self.__work:
            threading.Thread(target=self.getInput).start()
            self.__work = False

        if self.__mainInput != "\0" and self.__middleInput != "\0" and self.__lastInput != "\0" and self.__finalInput != "\0":
            self.__work = True
            if self.__mainInput == 1:#create platoon
                manager.addPlatoon(self.__middleInput)
            elif self.__mainInput == 2:#add traffic sign:
                if self.__middleInput == 1:#Follow the first vehicle in a platoon
                    p = manager.getPlatoon(self.__lastInput)
                    if p != None:
                        '''leader=p.getLeader()
                        #v = manager.getVehicle(self.__middleInput)
                        e = traci.lane.getEdgeID(traci.vehicle.getLaneID(v.getName()))
                        route = list(v.getRoute())
                        index = route.index(e)
                        route = route[index:]'''
                        sign = platoonSign("Follow", None)
                        p.addSign(sign)
                    else:
                        print("Error")
                    print("Follow the first vehicle in a platoon in reverse direction too")
                elif self.__middleInput == 2.1:#Dynamic vehicle/platoon distance restriction
                    #v = manager.getVehicle(self.__lastInput)
                    #v.setSign(["MinGap", self.__finalInput])
                    p = manager.getPlatoon(self.__lastInput)
                    if p != None:
                        sign = platoonSign("MinGap", self.__finalInput)
                        p.addSign(sign)
                    else:
                        v = manager.getVehicle(self.__lastInput)
                        if v != None:
                            sign = vehicleSign("MinGap", self.__finalInput)
                            v.setSign(sign)
                elif self.__middleInput == 2.2:#cancel Dynamic vehicle/platoon distance restriction
                    #v = manager.getVehicle(self.__lastInput)
                    #v.setSign(["MinGap", self.__finalInput])
                    p = manager.getPlatoon(self.__lastInput)
                    if p != None:
                        sign = p.getSign("MinGap")
                        if sign != None:
                            p.deleteSign(sign)
                    else:
                        v = manager.getVehicle(self.__lastInput)
                        if v != None:
                            sign = v.getSign("MinGap")
                            if sign != None:
                                v.deleteSign(sign)
                elif self.__middleInput == 3.1:  # Integration sign
                    #self.__lastInput = 'L' + self.__lastInput[0:-2]
                    l = manager.getMap().getEdge('L' + self.__lastInput[0:-2])
                    if l != None:
                        sign = laneSign("MinGap", self.__finalInput,self.__lastInput)
                        l.addSign(sign)
                elif self.__middleInput == 3.2:  # cancel Integration sign
                    self.__lastInput = 'L' + self.__lastInput[0:-2]
                    l = manager.getMap().getEdge(self.__lastInput)
                    if l != None:
                        sign = l.getSign("MinGap")
                        if sign!=None:
                            l.deleteSign(sign)
                elif self.__middleInput == 4.1:#No entry
                    lst = 'pedestrian bicycle tram rail_urban rail rail_electric rail_fast ship '+self.__finalInput
                    lst=lst.split(' ')
                    traci.lane.setDisallowed(self.__lastInput, lst)
                elif self.__middleInput == 4.2:#Open entry
                    lst = 'pedestrian bicycle tram rail_urban rail rail_electric rail_fast ship'.split(
                        ' ')
                    traci.lane.setDisallowed(self.__lastInput, lst)
                elif self.__middleInput == 5.1:#Limitation of lane speed for platoon
                    self.__lastInput = 'L' + self.__lastInput[0:-2]
                    l = manager.getMap().getEdge(self.__lastInput)
                    if l != None:
                        sign = platoonSign("MaxSpeed", self.__finalInput)
                        l.addSign(sign)
                elif self.__middleInput == 5.2:#cancel Limitation of lane speed for platoon
                    self.__lastInput = 'L' + self.__lastInput[0:-2]
                    l = manager.getMap().getEdge(self.__lastInput)
                    if l != None:
                        sign = l.getSign("MaxSpeedP")
                        if sign != None:
                            l.deleteSign(sign)
                elif self.__middleInput == 6:#Limitation of lane speed
                    #add sign by SUMO traci
                    traci.lane.setMaxSpeed(self.__lastInput,self.__finalInput)
                elif self.__middleInput == 7.1:  # change vehicle/platoon speed
                    #v = manager.getVehicle(self.__lastInput)
                    # v.setSign(["MaxSpeed", self.__finalInput])
                    p=manager.getPlatoon(self.__lastInput)
                    if p!=None:
                        sign=platoonSign("MaxSpeed",self.__finalInput)
                        p.addSign(sign)
                    else:
                        v = manager.getVehicle(self.__lastInput)
                        if v!=None:
                            sign = vehicleSign("MaxSpeed", self.__finalInput)
                            v.setSign(sign)
                elif self.__middleInput == 7.2:  # change vehicle/platoon speed
                    #v = manager.getVehicle(self.__lastInput)
                    # v.setSign(["MaxSpeed", self.__finalInput])
                    p = manager.getPlatoon(self.__lastInput)
                    if p != None:
                        sign = p.getSign("MaxSpeed")
                        if sign != None:
                            p.deleteSign(sign)
                    else:
                        v = manager.getVehicle(self.__lastInput)
                        if v != None:
                            sign = v.getSign("MaxSpeed")
                            if sign != None:
                                v.deleteSign(sign)
                elif self.__middleInput == 8:#Limitation of lane number of vehicles
                    #self.__lastInput = 'L' + self.__lastInput[0:-2]
                    l = manager.getMap().getEdge('L' + self.__lastInput[0:-2])
                    if l != None:
                        sign = laneSign("numLim", self.__finalInput,self.__lastInput)
                        l.addSign(sign)
                elif self.__middleInput == 9:#Follow the behavior of the first vehicle in a platoon
                    p = manager.getPlatoon(self.__lastInput)
                    if p != None:
                        '''leader=p.getLeader()
                        #v = manager.getVehicle(self.__middleInput)
                        e = traci.lane.getEdgeID(traci.vehicle.getLaneID(v.getName()))
                        route = list(v.getRoute())
                        index = route.index(e)
                        route = route[index:]'''
                        sign = platoonSign("FollowBehavior", p)
                        p.addSign(sign)
                    else:
                        print("Error")
                    print("Follow the behavior first vehicle in a platoon in reverse direction too")
            elif self.__mainInput == 3:#get leader instruction
                p = manager.getPlatoon(self.__middleInput)
                if p != None and p.getSign("FollowBehavior")!=None:
                    leader=p.getLeader()
                    lane = manager.getMap().getEdge(leader.getEdgeName())
                    #edge=leader.getEdgeName()
                    location=leader.getDistance()
                    if self.__lastInput==1:#change the speed
                        sign = platoonSign("MaxSpeedFollow", [location,self.__finalInput])
                        lane.addSign(sign)
                    elif (self.__lastInput == 2):#change lane
                        sign = platoonSign("LaneChangeFollow", [location, self.__finalInput])
                        lane.addSign(sign)
                '''self.__lastInput = 'L' + self.__lastInput[0:-2]
                l = manager.getMap().getEdge(self.__lastInput)
                # self.__finalInput = input("enter types for block\n")
                if l != None:
                    sign = platoonSign("MaxSpeed", self.__finalInput)
                    l.addSign(sign)
                v = manager.getVehicle(self.__middleInput)
                v.setSpeed(self.__lastInput)'''
            else:
                print("wrong input!!")
            self.resetGlobals()
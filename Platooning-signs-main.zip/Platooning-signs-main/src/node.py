import logging
import traci
import random

class Node():

    def __init__(self,name,inEdges,outEgdes):
        self.__name = name
        self.__inEdges=inEdges
        self.__outEgdes=outEgdes
        #print("end function init__Node")

    def getName(self):
        return self.__name

    def getInEdges(self):
        return self.__inEdges

    def getOutEdges(self):
        return self.__outEgdes

    def printNode(self):
        print("end function printNode")

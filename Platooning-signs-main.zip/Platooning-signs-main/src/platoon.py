
class Platoon():

    def __init__(self, representative,simulation):
        self.__X=70
        self.__representative=representative
        self.__leader=None
        self.__color=(153,255,255)
        representative.setPlatoonPointer(self,'platoonRep')
        self.__leader = representative
        # build the list platoon
        self.__vehiclesList = self.buildVehiclesList(representative, simulation)
        self.__isAlive=True
        self.__signs=[]
        self.__simulation=simulation

    def getThreshold(self):
        return self.__X

    def getSign(self,signName):
        for s in self.__signs:
            if s.getName()==signName:
                return s
        return None

    def addSign(self,sign):
        if sign.getName()=="Follow":
            #self.__leader.setRoute(self.__leader,sign)
            self.__signs.append(sign)
            self.addFollowSign(sign,self.__simulation)
        else:
            self.__representative.setSign(sign)
            self.__signs.append(sign)
            for v in self.__vehiclesList:
                v.setSign(sign)

    def addFollowSign(self,sign,simulation):
        currentEdge = simulation.getMap().getEdge(self.__leader.getEdgeName())
        # get all the vehicles on sorted list
        sortedListVehicles = currentEdge.getSortedVehiclesOn()
        sortedListVehicles = sortedListVehicles[::-1]
        if sortedListVehicles == None:
            sortedListVehicles = []
        # get the the sign to all the negative vehicles in the platoon
        self.setSignFollowToNegVehiclesPlatoon(currentEdge, self.__leader, sortedListVehicles, simulation, [currentEdge],sign)

    def setSignFollowToNegVehiclesPlatoon(self, currentEdge, currentVehicle, negList, simulation,path,sign):
        for v in negList:
            if (not v.isActive()) or(not currentVehicle.isActive()):
                return
            d = simulation.getMap().getDistanceBetweenTwoVehicles(v, currentVehicle, path)
            if (d) <= ((self.__X + currentVehicle.getSpeed()) / 3.7):
                v.setRoute(currentVehicle,sign)
                currentVehicle = v
                path = [currentEdge]
            else:
                return
        if negList == []:
            v = currentVehicle
        else:
            v = negList[-1]
        neighborsEdges = simulation.getMap().getReverseNeighbors(currentEdge.getName())
        for n in neighborsEdges:
            # get all the vehicles on reverse sort
            currentEdge = simulation.getMap().getEdge(n)
            path.append(currentEdge)
            neg = currentEdge.getSortedVehiclesOn()
            neg = neg[::-1]
            if neg != None:
                self.setSignFollowToNegVehiclesPlatoon(currentEdge, v, neg, simulation, path, sign)
            elif currentEdge.getLenght()> ((self.__X + currentVehicle.getSpeed()) / 3.7):
                self.setSignFollowToNegVehiclesPlatoon(currentEdge, v, [], simulation, path, sign)
            path.remove(currentEdge)
        return

    def deleteSign(self,sign):
        self.__representative.deleteSign(sign)
        for v in self.__vehiclesList:
            v.deleteSign(sign)
        self.__signs.remove(sign)

    def deleteVehicle(self,vehicle):
        if vehicle in self.getVehicleList():
            self.__vehiclesList.remove(vehicle)
            vehicle.setPlatoonPointer(None,'normal_car')
            #if vehicle.isActive():
             #   vehicle.setColor((255, 255, 0))

    def buildVehiclesList(self, representative, simulation):
        # get the current array that the representative in
        currentEdge = simulation.getMap().getEdge(representative.getEdgeName())
        # get all the vehicles on sorted list
        sortedListVehicles = currentEdge.getSortedVehiclesOn()
        #slice the vehiclesOn list according the representative position in the representative edge
        representativeIndex = sortedListVehicles.index(representative)
        pos = sortedListVehicles[representativeIndex + 1:]
        neg = sortedListVehicles[:representativeIndex]
        neg = neg[::-1]
        if neg == None:
            neg = []
        if pos == None:
            pos = []
        # all the negative vehicles in the platoon
        neg = self.getNegVehiclesPlatoon(currentEdge, representative, neg, simulation,[currentEdge])
        # the positive vehicles in the platoon from next node
        pos = self.getPosVehiclesPlatoon(currentEdge, representative, pos, simulation,[currentEdge])
        #TODO sometimes there are too much leaders to check why!!!!
        if len(pos)>0:
            v=pos[-1]
            if self.__leader!=v:
                if (self.__leader in pos)or (self.__leader in neg):
                    self.__leader.setPlatoonPointer(self, 'platoon')
                    signs = self.__leader.getSigns()
                    for s in signs:
                        self.__leader.deleteSign(s)
                        self.__leader.setSign(s)
                v.setPlatoonPointer(self, 'platoonLead')
                self.__leader=v
                signs=v.getSigns()
                for s in signs:
                    v.deleteSign(s)
                    v.setSign(s)
        else:#if the representative is the leader
            self.__leader = self.__representative
        return pos + neg

    def getPosVehiclesPlatoon(self, currentEdge, currentVehicle, posList, simulation, path):
        realList = []
        for v in posList:
            d = simulation.getMap().getDistanceBetweenTwoVehicles(currentVehicle,v,  path)
            if (d) <= ((self.__X + currentVehicle.getSpeed()) / 3.7):
                '''if (v.getPlatoonPointer()!=None)and (v.getPlatoonPointer()!=self):
                    #v.getPlatoonPointer().deletePlatoon()
                    self.__isAlive=False'''
                if v.getPlatoonPointer() != self:
                    v.setPlatoonPointer(self,'platoon')
                    #TODO add this 4 lanes
                    signs = v.getSigns()
                    for s in signs:
                        v.deleteSign(s)
                        v.setSign(s)
                    #v.setColor(self._color)
                realList.append(v)
                currentVehicle = v
                path = [currentEdge]
            else:
                return realList
        if posList == []:
            v = currentVehicle
        else:
            v = posList[-1]
        neighborsEdges = simulation.getMap().getNeighbors(currentEdge.getName())
        for n in neighborsEdges:
            # get all the vehicles on sort
            currentEdge = simulation.getMap().getEdge(n)
            path.append(currentEdge)
            pos = currentEdge.getSortedVehiclesOn()
            if pos == None:
                pos = []
            realList = realList + self.getPosVehiclesPlatoon(currentEdge, v, pos, simulation, path)
            path.remove(currentEdge)
        return realList

    def getNegVehiclesPlatoon(self, currentEdge, currentVehicle, negList, simulation,path):
        realList = []
        #path = path[::-1]
        for v in negList:
            d = simulation.getMap().getDistanceBetweenTwoVehicles(v,currentVehicle, path)
            if (d) <= ((self.__X + currentVehicle.getSpeed()) / 3.7):
                if (v.getPlatoonPointer()!=None)and (v.getPlatoonPointer()!=self):
                    #v.getPlatoonPointer().deletePlatoon()
                    self.__isAlive=False
                if v.getPlatoonPointer()!=self:
                    v.setPlatoonPointer(self,'platoon')
                    # TODO add this 4 lanes
                    signs = v.getSigns()
                    for s in signs:
                        v.deleteSign(s)
                        v.setSign(s)
                #v.setColor(self._color)
                realList.append(v)
                currentVehicle = v
                path = [currentEdge]
            else:
                return realList
        if negList == []:
            v = currentVehicle
        else:
            v = negList[-1]
        neighborsEdges = simulation.getMap().getReverseNeighbors(currentEdge.getName())
        for n in neighborsEdges:
            # get all the vehicles on reverse sort
            currentEdge = simulation.getMap().getEdge(n)
            path.append(currentEdge)
            neg = currentEdge.getSortedVehiclesOn()
            neg = neg[::-1]
            if neg == None:
                neg = []
            realList = realList + self.getNegVehiclesPlatoon(currentEdge, v, neg, simulation,path)
            path.remove(currentEdge)
        return realList

    def updatePlatoon(self,simulation):
        represetative = simulation.getVehicle(self.__representative.getName())
        if self.__isAlive==False:
            return False
        # if the representative is is still in the simulation
        if represetative.isActive():
            oldVehiclesList=self.getVehicleList()
            # build the new list platoon
            newVehiclesList = self.buildVehiclesList(self.__representative, simulation)
            #update all the old vehicles from the list
            for o in oldVehiclesList:
                #delete for vehicle the traffic signs that need to delete
                if o not in newVehiclesList:
                    for s in self.__signs:
                        o.deleteSign(s)
                    o.setPlatoonPointer(None,'normal_car')
                    #o.setColor((255, 255, 0))
            #update all the new vehicles that needs to get new traffic sign
            self.__vehiclesList = newVehiclesList
            # update all the new vehicles in the list to get the sings
            if len(self.__signs)>0:
                for s in self.__signs:
                    if s.getName()=="Follow":
                        self.addFollowSign(s,simulation)
                    else:
                        for o in self.__vehiclesList:
                            o.setSign(s)
            return True
        else:
            self.deletePlatoon()
            return False

    def deletePlatoon(self):
        #self.__representative.setColor((255, 255, 0))
        self.__representative.setPlatoonPointer(None,'normal_car')
        for v in self.getVehicleList():
            v.setPlatoonPointer(None,'normal_car')
            #v.setColor((255, 255, 0))
            #v.defualtSigns()
        for s in self.__signs:
            self.deleteSign(s)
        self.__vehiclesList=[]
        self.__isAlive=False

    def getLeader(self):
        return self.__leader

    def getVehicleList(self):
        return self.__vehiclesList

    def getRepresentativeName(self):
        if self.__representative==None:
            return None
        return self.__representative.getName()

    def getIsAlive(self):
        return self.__isAlive
import logging
import traci
import random
from abc import ABC, abstractmethod

class Sign(ABC):

    def __init__(self, name,value):
        self.__name=name
        self.__value=value

    def getName(self):
        return self.__name

    def setName(self,name):
        self.__name=name

    def getValue(self):
        if type(self.__value) is list:
            return self.__value[1]
        return self.__value

    def getValueList(self):
        return self.__value

    def getType(self):
        pass

class platoonSign(Sign):
    '''def __init__(self, name,value):
        self.__name=name
        self.__value=value

    def getName(self):
        return self.__name

    def getValue(self):
        return self.__value'''
    def getType(self):
        return 'platoonSign'

class laneSign(Sign):

    def __init__(self, name,value,lane):
        self.__name=name
        self.__value=value
        self.__lane=lane

    def getName(self):
        return self.__name

    def getValue(self):
        return self.__value

    def getType(self):
        return 'laneSign'

    def getLane(self):
        return self.__lane

class vehicleSign(Sign):
    def getType(self):
        return 'vehicleSign'
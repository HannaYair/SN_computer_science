import logging
import traci
import random
from src.sign import platoonSign,laneSign,vehicleSign
class Edge():

    def __init__(self,name,fromNode,toNode,vehiclesOn,lenght):
        self.__name=name
        self.__fromNode=fromNode
        self.__toNode=toNode
        #list of vehicle objects
        self.__vehiclesOn = vehiclesOn
        self.__lenght=lenght
        self.__signs=[]

    def getSign(self,sign):
        if type(sign) == str:
            if sign[-1]=='P':
                sign=sign[0:-1]
                for s in self.__signs:
                    if (s.getName()==sign)and (type(s)==platoonSign):
                        return s
            else:
                for s in self.__signs:
                    if s.getName()==sign:
                        return s
        else:
            for s in self.__signs:
                if (s== sign):
                    return s
        return None

    def setBlocked(self,name):
        print("setBlocked")

    def getName(self):
        return self.__name

    def getFromNode(self):
        return self.__fromNode

    def getToNode(self):
        return self.__toNode

    def getLenght(self):
        return self.__lenght

    def getVehiclesOn(self):
        return self.__vehiclesOn

    def getSortedVehiclesOn(self):
        distances = {}
        for v in self.__vehiclesOn:
            distances[v] = v.getDistance()
        distances = sorted(distances.items(), key=lambda x:x[1])
        self.__vehiclesOn = []
        for t in distances:
            self.__vehiclesOn.append(t[0])
        return self.__vehiclesOn
    '''def getSortedVehiclesOn(self):
        distances={}
        for v in self.__vehiclesOn:
            distances[v.getDistance()]=v
        distances=sorted(distances.items())
        self.__vehiclesOn=[]
        for t in distances:
            self.__vehiclesOn.append(t[1])
        return self.__vehiclesOn'''

    def getSortedReverseVehiclesOn(self):
        distances={}
        for v in self.__vehiclesOn:
            distances[v.getDistance()]=v
        distances=sorted(distances.items(),reverse=True)
        self.__vehiclesOn=[]
        for t in distances:
            self.__vehiclesOn.append(t[1])
        return self.__vehiclesOn

    def addVehicle(self,vehicle):
        self.__vehiclesOn.append(vehicle)
        for s in self.__signs:
            #t=traci.vehicle.getTypeID(vehicle.getName())
            if s.getType()!='platoonSign':
                if s.getName() == 'numLim':
                    if self.counfOfVehiclesOnLane(s.getLane()) >= s.getValue():
                        lst = ['authority']
                        traci.lane.setAllowed(s.getLane(), lst)
                else:
                    vehicle.setSign(s)
            elif traci.vehicle.getTypeID(vehicle.getName())!="normal_car":
                if vehicle.getPlatoonPointer()!=None:
                    vehicle.setSign(s)

    def deleteVehicle(self,vehicle):
        for v in self.__vehiclesOn:
            if v.getName()==vehicle.getName():
                for s in self.__signs:
                    if s.getName() == 'numLim':
                        if self.counfOfVehiclesOnLane(s.getLane()) < s.getValue():
                            lst = 'pedestrian bicycle tram rail_urban rail rail_electric rail_fast ship'.split(
                                ' ')
                            traci.lane.setDisallowed(s.getLane(), lst)
                    else:
                        v.deleteSign(s)
                self.__vehiclesOn.remove(v)
                break

    def addSign(self,Sign):
        self.__signs.append(Sign)
        #class_name = Sign.getType()
        if Sign.getType()!='platoonSign':
            if Sign.getName()=='numLim':
                if self.counfOfVehiclesOnLane(Sign.getLane())>=Sign.getValue():
                    lst = ['authority']
                    traci.lane.setDisallowed(Sign.getLane(), lst)
            else:
                for v in self.__vehiclesOn:
                    v.setSign(Sign)
        else:#platoon sign
            if Sign.getName() == 'MaxSpeedFollow' or Sign.getName() == 'LaneChangeFollow':
                for v in self.__vehiclesOn:
                    '''#type=traci.vehicle.getTypeID(v.getName())
                    #if (traci.vehicle.getTypeID(v.getName())!="normal_car")and (v.getSign("FollowBehavior")!=None):
                    #if (v.getPlatoonPointer()==Sign.getValue()[0]) and (v.getSign("FollowBehavior") != None) :
                    if (v.getPlatoonPointer() != None)and (v.getPlatoonPointer().getSign("FollowBehavior")!=None):
                        if v.getPlatoonPointer().getSign("FollowBehavior").getValue()==v.getPlatoonPointer():
                            v.setSign(Sign)'''
                    if v.getPlatoonPointer()!=None:
                        if v.getPlatoonPointer().getSign("FollowBehavior")!=None:
                            v.setSign(Sign)
            else:
                for v in self.__vehiclesOn:
                    #type=traci.vehicle.getTypeID(v.getName())
                    if traci.vehicle.getTypeID(v.getName())!="normal_car":
                        v.setSign(Sign)

    def getSignByDistance(self,vehicle,signName):
        for s in self.__signs:
            if s.getName()==signName :
                location=s.getValueList()[0]
                #a=self.getPlatoonPointer()
                X=vehicle.getPlatoonPointer().getThreshold()
                dist=vehicle.getDistance()
                if (vehicle.getDistance()>(location-0.1*X))and(vehicle.getDistance()<location+0.1*X):
                    return s
        return None

    def setVehicleFollowBehaviorSign(self,vehicle):
        if vehicle.getPlatoonPointer() != None:
            sign=self.getSignByDistance(vehicle,"MaxSpeedFollow")
            if sign!=None:
                vehicle.setSign(sign)
            else:
                sign = self.getSignByDistance(vehicle, "LaneChangeFollow")
                if sign != None:
                    vehicle.setSign(sign)

    def deleteSign(self,sign):
        for v in self.__vehiclesOn:
            if sign.getName() != 'numLim':
                v.deleteSign(sign)
            else:
                lst = 'pedestrian bicycle tram rail_urban rail rail_electric rail_fast ship'.split(
                    ' ')
                traci.lane.setAllowed(sign.getLane(), lst)
        self.__signs.remove(sign)

    def counfOfVehiclesOnLane(self,lane):
        count=0
        for v in self.__vehiclesOn:
            laneV=traci.vehicle.getLaneID(v.getName())
            if lane==laneV:
                count=count+1
        return count
import traci
from src.sign import Sign
from src.sign import vehicleSign
class Vehicle():
    
    def __init__(self, vehicle):
        self._active = True
        self._acceleration = traci.vehicle.getAcceleration(vehicle)
        self._length = traci.vehicle.getLength(vehicle)
        self._maxSpeed = traci.vehicle.getMaxSpeed(vehicle)
        self._name = vehicle
        self._route = traci.vehicle.getRoute(vehicle)
        self._previouslySetValues = dict()
        #self._edge="L"+traci.vehicle.getRoadID(self.getName())
        self._edgeName = "L" + traci.vehicle.getLaneID(self.getName())[0:-2]
        self._distance=0.0
        #traci name lane[0:-2]
        self._oldEdgeName="L" + traci.vehicle.getLaneID(self.getName())[0:-2]
        self._platoonPointer=None
        self._target=self._route[-1]
        self._signs=[]

    def getAcceleration(self):
        return self._acceleration

    def isActive(self):
        return self._active
    
    def getEdgeName(self):
        return self._edgeName

    def getLane(self):
        return traci.vehicle.getLaneID(self.getName())[0:-2]

    def getLaneIndex(self):
        return traci.vehicle.getLaneIndex(self.getName())

    def getLanePosition(self):
        return traci.vehicle.getLanePosition(self.getName())

    def getPosition(self):
        return traci.vehicle.getPosition3D(self.getName())

    def getLanePositionFromFront(self):
        return traci.lane.getLength(self.getLane()) - self.getLanePosition()

    def getLeader(self):
        return traci.vehicle.getLeader(self.getName(), 20)

    def getLength(self):
        return self._length

    def getMaxSpeed(self):
        return self._maxSpeed

    def getName(self):
        return self._name

    def getRemainingRoute(self):
        return self._route[traci.vehicle.getRouteIndex(self.getName()):]

    def getRoute(self):
        return self._route


    '''
    v1 = manager.getVehicle(self.__middleInput)
    v2 = manager.getVehicle(self.__lastInput)
    v1.setColor((0,255,0))
    v2.setColor((0, 255, 0))
    e1 = traci.lane.getEdgeID(traci.vehicle.getLaneID(v1.getName()))
    e2 = traci.lane.getEdgeID(traci.vehicle.getLaneID(v2.getName()))
    route=list(v1.getRoute())
    index=route.index(e1)
    route=route[index:]
    name=v2.getName()
    print(v1.getRoute())
    print(v2.getRoute())
    if(e1==e2):
        traci.vehicle.setRoute(name,route)
    '''

    def setRoute(self,vehicle,sign):
        self._signs.append(sign)
        e1 = traci.lane.getEdgeID(traci.vehicle.getLaneID(vehicle.getName()))
        e2 = traci.lane.getEdgeID(traci.vehicle.getLaneID(self.getName()))
        if e1[0] != ":" and e2[0] != ":":
            route = list(vehicle.getRoute())
            index = route.index(e1)
            route = route[index:]
            if (e1 == e2):
                traci.vehicle.setRoute(self.getName(), route)
                self._route = traci.vehicle.getRoute(self.getName())
            else:
                route.insert(0, e2)
                traci.vehicle.setRoute(self.getName(), route)
                self._route = traci.vehicle.getRoute(self.getName())

    def getSpeed(self):
        return traci.vehicle.getSpeed(self.getName())

    def getOldEdgeName(self):
        return self._oldEdgeName

    def getDistance(self):
        #get the distance from the start point of the current edge to the current point
        x=traci.vehicle.getDistance(self.getName())
        #return x
        return abs(traci.vehicle.getDistance(self.getName())-self._distance)

    def setEdgeName(self,edgeName):
        self.setOldEdgeName(self._edgeName)
        self._edgeName=edgeName

    def setOldEdgeName(self,edgeName):
        self._OldedgeName=edgeName

    def getPlatoonPointer(self):
        return self._platoonPointer

    def getSign(self,sign):
        if type(sign)==str:
            for s in self._signs:
                if s.getName()==sign and (type(s)==vehicleSign  or sign=="MaxSpeedFollow"):
                    return s
        else:
            for s in self._signs:
                if s==sign:
                    return s
        return None


    def setSign(self,sign):
        if self._active:
            if sign.getName()=="MaxSpeedFollow" :
                location=sign.getValueList()[0]
                #a=self.getPlatoonPointer()
                X=self.getPlatoonPointer().getThreshold()
                if (self.getDistance()>=location-0.1*X)and(self.getDistance()<=location):
                    value=sign.getValue()
                    # TODO add sign without multiples
                    '''if sign not in self._signs:
                        self._signs.append(sign)
                    self.setMaxSpeed(sign.getValue())'''
                    oldSign=self.getSign("MaxSpeedFollow")
                    if oldSign==None:
                        self._signs.append(sign)
                    elif oldSign!=sign:
                        self.deleteSign(oldSign)
                        self._signs.append(sign)
                    self.setMaxSpeed(sign.getValue())
            elif sign.getName()=="LaneChangeFollow":
                location=sign.getValueList()[0]
                #a=self.getPlatoonPointer()
                X=self.getPlatoonPointer().getThreshold()
                if (self.getDistance()>=location-0.1*X)and(self.getDistance()<=location):
                    value=sign.getValue()
                    # TODO add sign without multiples
                    '''if sign not in self._signs:
                        self._signs.append(sign)
                    self.setMaxSpeed(sign.getValue())'''
                    oldSign=self.getSign("LaneChangeFollow")
                    if oldSign==None:
                        self._signs.append(sign)
                    elif oldSign!=sign:
                        self.deleteSign(oldSign)
                        self._signs.append(sign)
                    lane=sign.getValue()[-1]
                    time=70/self.getSpeed()
                    traci.vehicle.changeLane(self.getName(),lane,time)
            elif sign.getName() == "MaxSpeed":
                # TODO add sign without multiples
                if sign not in self._signs:
                    self._signs.append(sign)
                self.setMaxSpeed(sign.getValue())
            elif sign.getName()=="MinGap":
                # TODO add sign without multiples
                if sign not in self._signs:
                    self._signs.append(sign)
                self.setMinGap(sign.getValue())
            else:
                # TODO add sign without multiples
                if sign not in self._signs:
                    self._signs.append(sign)


    def getSigns(self):
        return self._signs

    def deleteSign(self,sign):
        if self._active:
            for s in self._signs:
                if sign==s:
                    self.defualtSign(sign)
                    self._signs.remove(sign)
                    break

    def setPlatoonPointer(self,platoonPointer,type):
        if self.isActive():
            traci.vehicle.setType(self.getName(),type)
        self._platoonPointer=platoonPointer

    def setMaxSpeed(self, maxSpeed):
        self._maxSpeed = maxSpeed
        #self._setAttr("setMaxSpeed", maxSpeed)
        traci.vehicle.setMaxSpeed(self.getName(),maxSpeed)

    def setColor(self, color):
        self._setAttr("setColor", color)

    def setInActive(self):
        self._active = False

    def setImperfection(self, imperfection):
        self._setAttr("setImperfection", imperfection)

    def setMinGap(self, minGap):
        self._setAttr("setMinGap", minGap)

    def setTargetLane(self, lane):
        traci.vehicle.changeLane(self.getName(), lane, 0.5)

    def setTau(self, tau):
        self._setAttr("setTau", tau)

    def setSpeed(self, speed):
        self._setAttr("setSpeed", speed)

    def setSpeedMode(self, speedMode):
        self._setAttr("setSpeedMode", speedMode)

    def setSpeedFactor(self, speedFactor):
        self._setAttr("setSpeedFactor", speedFactor)

    def setOldEdgeName(self,edgeName):
        self._oldEdgeName=edgeName

    '''def setDistance(self,distance):
        x=traci.vehicle.getDistance(self.getName())
        if 0<=traci.vehicle.getDistance(self.getName())>=0.01:
            self._distance = traci.vehicle.getDistance(self.getName())
        else:
            self._distance=self._distance+distance
        #self._distance=traci.vehicle.getDistance(self.getName())'''

    def setDistance(self,distance):
        x=traci.vehicle.getDistance(self.getName())
        if (self._distance>=0.0) or (self._distance<=2.0):
            self._distance = traci.vehicle.getDistance(self.getName())
        else:
            self._distance=self._distance+distance
        #self._distance=traci.vehicle.getDistance(self.getName())

    '''def defualtSigns(self):
        #TODO to decide what will be the defualt values of all the signs 
        for s in self._signs:
            if s[0]=="MaxSpeed":
                self._setAttr("set"+s[0],55.56)
            elif s[0]=="MinGap":
                traci.vehicle.setMinGap(self.getName(),2.5)
        self._signs=[]'''

    def defualtSign(self,sign):
        #TODO to decide what will be the defualt values of all the signs
        if sign.getName()=="MaxSpeed" or sign.getName()=="MaxSpeedFollow":
            #if self.getName()=="RoundInA12North.2":
             #   print("STOP!!")
            self._setAttr("setMaxSpeed",55.56)
        elif sign.getName()=="MinGap":
            traci.vehicle.setMinGap(self.getName(),2.5)
        elif(sign.getName()=="FollowBehavior"):
            return
        else:#if it is follow sign return the previos route
            try:
                traci.vehicle.changeTarget(self.getName(),self._target)
            except traci.exceptions.TraCIException:
                print(" ")

    def _setAttr(self, attr, arg):
        # Only set an attribute if the value is different from the previous value set
        # This improves performance
        if self.isActive():
            '''if attr in self._previouslySetValues:
                if self._previouslySetValues[attr] == arg:
                    return'''
            self._previouslySetValues[attr] = arg
            getattr(traci.vehicle, attr)(self.getName(), arg)
'''
from src.intersectionController import IntersectionController
from src.platoon import Platoon
from src.vehicle import Vehicle
from src.simlib import flatten

import traci

class SimulationManager():

    def __init__(self, pCreation=True, iCoordination=True, iZipping=True):
        self.intersections = []
        self.platoons = list()
        self.platoonCreation = pCreation
        self.vehicles = list()
        self.maxStoppedVehicles = dict()
        if iCoordination:
            for intersection in traci.trafficlight.getIDList():
                controller = IntersectionController(intersection, iZipping)
                self.intersections.append(controller)

    def createPlatoon(self, vehicles):
        # Creates a platoon with the given vehicles
        platoon = Platoon(vehicles)
        self.platoons.append(platoon)

    def getActivePlatoons(self):
        # Gets all active platoons
        return [p for p in self.platoons if p.isActive()]

    def getAllVehiclesInPlatoons(self):
        # Gets all vehicles in every active platoon
        return flatten(p.getAllVehiclesByName() for p in self.getActivePlatoons())

    def getAverageLengthOfAllPlatoons(self):
        count = 0
        length = len(self.platoons)
        for platoon in self.platoons:
            if platoon._disbandReason != "Merged" and platoon._disbandReason != "Reform required due to new leader":
                count = count + platoon.getNumberOfVehicles()
            else:
                length = length - 1
        return count/length

    def getPlatoonByLane(self, lane):
        # Gets platoons corresponding to a given lane
        return [p for p in self.getActivePlatoons() if lane == p.getLane()]

    def getPlatoonByVehicle(self, v):
        return [p for p in self.getActivePlatoons() if v in p.getAllVehiclesByName()]

    def getReleventPlatoon(self, vehicle):
        # Returns a single platoon that is most relevent to the given
        # vehicle by looking to see if the car in front is part of a platoon
        # It also checks that the platoon is heading in the right direction
        leadVeh = vehicle.getLeader()
        if leadVeh and leadVeh[1] < 10:
            possiblePlatoon = self.getPlatoonByVehicle(leadVeh[0])
            if possiblePlatoon:
                if possiblePlatoon[0].checkVehiclePathsConverge([vehicle]) and vehicle not in possiblePlatoon[0].getAllVehicles():
                    return possiblePlatoon[0]

    def handleSimulationStep(self):
        allVehicles = traci.vehicle.getIDList()
        # Check mark vehicles as in-active if they are outside the map
        stoppedCount = dict()
        for v in self.vehicles:
            if v.getName() not in allVehicles:
                v.setInActive()
            # Get information concerning the number of vehicles queueing on each lane
            if v.isActive() and v.getSpeed() == 0:
                lane = v.getEdge()
                if lane in stoppedCount:
                    stoppedCount[lane] = stoppedCount[lane] + 1
                else:
                    stoppedCount[lane] = 1

        # Gather statistics for amount of vehicles stopped per lane
        for lane in stoppedCount:
            if lane in self.maxStoppedVehicles:
                if stoppedCount[lane] > self.maxStoppedVehicles[lane]:
                    self.maxStoppedVehicles[lane] = stoppedCount[lane]
            else:
                self.maxStoppedVehicles[lane] = stoppedCount[lane]

        # Update all platoons active status
        for p in self.getActivePlatoons():
            p.updateIsActive()

        if self.platoonCreation:
            # See whether there are any vehicles that are not
            # in a platoon that should be in one
            vehiclesNotInPlatoons = [v for v in allVehicles if v not in self.getAllVehiclesInPlatoons()]

            for vehicleID in vehiclesNotInPlatoons:
                vehicle = Vehicle(vehicleID)
                self.vehicles.append(vehicle)
                vehicleLane = vehicle.getLane()
                # If we're not in a starting segment (speed starts as 0)
                possiblePlatoon = self.getReleventPlatoon(vehicle)
                if possiblePlatoon:
                    possiblePlatoon.addVehicle(vehicle)
                else:
                    self.createPlatoon([vehicle, ])

        # If we're doing intersection management, update each controller and add any new platoons into their
        # control
        if self.intersections:
            for inControl in self.intersections:
                inControl.removeIrreleventPlatoons()
                inControl.findAndAddReleventPlatoons(self.getActivePlatoons())
                inControl.update()

        if self.platoonCreation:
            # Handles a single step of the simulation
            # Update all active platoons in the scenario
            for platoon in self.getActivePlatoons():
                platoon.update()
                if platoon.canMerge() and platoon.isActive():
                    lead = platoon.getLeadVehicle().getLeader()
                    if lead:
                        leadPlatoon = self.getPlatoonByVehicle(lead[0])
                        if leadPlatoon:
                            leadPlatoon[0].mergePlatoon(platoon)
'''


from src.platoon import Platoon
from src.vehicle import Vehicle
from src.graphRoute import graphRoute
import traci

class SimulationManager():

    def __init__(self):
        laneLinks = {}
        lanes=traci.lane.getIDList()
        for lane in lanes:
            laneLinks[lane]=traci.lane.getLinks(lane,True)
        #graphRoute object
        self.__map=graphRoute(lanes,laneLinks)
        '''
        edgeLinks = {}
        edges = traci.edge.getIDList()
        for lane in traci.lane.getIDList():
            edge=traci.lane.getEdgeID(lane)
            x = traci.lane.getLinks(lane, True)
            for i in range(len(x)):
                x[i] = traci.lane.getEdgeID(x[i])
            if edge in edgeLinks:
                edgeLinks[edge]=edgeLinks[edge]+x
            else:
                edgeLinks[edge] =x

        #graphRoute object
        self.__map=graphRoute(edges,edgeLinks)'''
        #vehicles objects
        self.__vehicles = list()
        #platoons objects
        self.__platoons = {}

    def handleSimulationStep(self):
        #all the vehicles in the simulation
        allVehicles = traci.vehicle.getIDList()
        allVehicles=list(allVehicles)
        #if vehicle not in simulation
        for v in self.__vehicles:
            if v.getName() not in allVehicles:
                v.setInActive()
                #delete the vehicle from the platoon
                platoon=v.getPlatoonPointer()
                if platoon !=None:
                    platoon.deleteVehicle(v)
                self.deleteVehicle(v)
            else:
                self.setVehicleEdgeName(v)
                self.setVehicleDistance(v)
                allVehicles.remove(v.getName())

        for v1 in allVehicles:
            #get location of vehicle
            if self.getVehicle(v1)==None:
                vehicle=Vehicle(v1)
                self.__vehicles.append(vehicle)
                #add vehicle to current edge
                lane = vehicle.getEdgeName()
                self.__map.getEdge(lane).addVehicle(vehicle)
        self.handlePlatoonsStep()

    def deleteVehicle(self,vehicle):
        self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)

    '''def setVehicleEdgeName(self,vehicle):
        lane =vehicle.getLane()
        if (lane[0] != ':'):
            #remove vehicle from prev edge
            self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
            #add vehicle to current edge
            self.__map.getEdge("L" +lane).addVehicle(vehicle)
            #update vahicle to current edge
            vehicle.setEdgeName("L" +lane)
        else:
            prevEdge=vehicle.getEdgeName()
            neighborsEdges=self.__map.getNeighbors(prevEdge)
            if len(neighborsEdges)==1:
                # remove vehicle from prev edge
                self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
                # add vehicle to current edge
                self.__map.getEdge(neighborsEdges[0]).addVehicle(vehicle)
                # update vahicle to current edge
                vehicle.setEdgeName(neighborsEdges[0])
            elif len(neighborsEdges)>1:
                name=prevEdge.split('_')[0][1:]
                index = vehicle.getRoute().index(name)
                for n in neighborsEdges:
                    if (name in n) and (vehicle.getRoute()[index+1] in n):
                        # remove vehicle from prev edge
                        self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
                        # add vehicle to current edge
                        self.__map.getEdge(n).addVehicle(vehicle)
                        # update vahicle to current edge
                        vehicle.setEdgeName(n)
                        break'''

    def setVehicleEdgeName(self,vehicle):

        lane =vehicle.getLane()
        '''if vehicle.getName() == 'A13New.0' and lane == '-553673729':
            print('g')'''
        if vehicle.getEdgeName() != ('L'+lane):
            if (lane[0] != ':'):
                #remove vehicle from prev edge
                self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
                #add vehicle to current edge
                self.__map.getEdge('L'+lane).addVehicle(vehicle)
                #update vahicle to current edge
                vehicle.setEdgeName('L'+lane)
            '''else:
                prevEdge=vehicle.getEdgeName()
                if prevEdge[0]!='j':
                    neighborsEdges=self.__map.getNeighbors(prevEdge)
                    if len(neighborsEdges)==1:
                        # remove vehicle from prev edge
                        self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
                        # add vehicle to current edge
                        self.__map.getEdge(neighborsEdges[0]).addVehicle(vehicle)
                        # update vahicle to current edge
                        vehicle.setEdgeName(neighborsEdges[0])
                    elif len(neighborsEdges)>1:
                        name=prevEdge.split('_')[0][1:]
                        e=vehicle.getRoute()
                        index = vehicle.getRoute().index(name)
                        for n in neighborsEdges:
                            if (name in n) and (vehicle.getRoute()[index+1] in n):
                                # remove vehicle from prev edge
                                self.__map.getEdge(vehicle.getEdgeName()).deleteVehicle(vehicle)
                                # add vehicle to current edge
                                self.__map.getEdge(n).addVehicle(vehicle)
                                # update vahicle to current edge
                                vehicle.setEdgeName(n)
                                break'''

    def setVehicleDistance(self,vehicle):
        currentEdgeName = vehicle.getEdgeName()
        # if the vehicle change edge
        if vehicle.getOldEdgeName()!=currentEdgeName:
            oldEdge = self.__map.getEdge(vehicle.getOldEdgeName())
            vehicle.setDistance(oldEdge.getLenght())
            junctionLenght=self.__map.getEdge('J' + vehicle.getOldEdgeName()[1:] + currentEdgeName[1:]).getLenght()
            vehicle.setDistance(junctionLenght)
            vehicle.setOldEdgeName(currentEdgeName)
        self.__map.getEdge(currentEdgeName).setVehicleFollowBehaviorSign(vehicle)

    def getVehicle(self,vehicleName):
        for v in self.__vehicles:
            if v.getName()==vehicleName:
                return v
        return None

    def getMap(self):
        return self.__map

    def addPlatoon(self,represetativeName):
        represetative=self.getVehicle(represetativeName)
        if represetative!=None:
            self.__platoons[represetativeName]=Platoon(represetative,self)
        else:
            print("error input")

    def getPlatoon(self,represetativeName):
        if represetativeName in self.__platoons.keys():
            return self.__platoons[represetativeName]
        return None

    def deletePlatoon(self,represetativeName):
        if represetativeName in self.__platoons.keys():
            self.__platoons.pop(represetativeName)

    def handlePlatoonsStep(self):
        deletePlatoons=[]
        for p in self.__platoons:
            #if the representative is not in the simulation updatePlatoon update the vehicles platoon the details
            platoon=self.getPlatoon(p)
            #if platoon==None or platoon.getRepresentativeName()==None:
            #    deletePlatoons.append(platoon.getRepresentativeName())
            if platoon.updatePlatoon(self)==False:
                deletePlatoons.append(platoon.getRepresentativeName())
        for p in deletePlatoons:
            platoon = self.getPlatoon(p)
            self.deletePlatoon(platoon.getRepresentativeName())

    def CountOfPlatoons(self):
        return len(self.__platoons)

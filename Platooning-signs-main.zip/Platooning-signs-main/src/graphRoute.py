import traci
from src.edge import Edge
from src.node import Node
import networkx as nx
import matplotlib.pyplot as plt
import math

class graphRoute():

    def __init__(self,lanes,laneLinks):
        self.__nodes = dict()
        self.__edges = dict()
        self.buildGraph(lanes,laneLinks)

    def printGraph(self,edges,locationNodes):
        # plot the graph to see if its make sense
        G = nx.DiGraph()
        x = []
        for k, v in edges.items():
            x.append((v[0], v[1]))
        G.add_edges_from(x)
        nx.draw_networkx(G, pos=locationNodes, with_labels=False)
        plt.show()

    #buildGraph function
    def buildGraph1(self, lanes,laneLinks):
        nodes = {}
        edges = {}
        locationNodes = {}
        # build empty nodes and lane edges
        for lane in lanes:
            if (lane[0] != ':'):
                #node [name,[in edges],[out edegs]]
                nodes['from' + lane] = [[], []]
                nodes['to' + lane] = [[], []]
                #edge [name,from node,to node ,[vehicles in edge],length]
                edges['L' + lane] = ['from' + lane, 'to' + lane, [], traci.lane.getLength(lane)]
                nodes['to' + lane][0].append('L' + lane)
                locationNodes['to' + lane]=traci.lane.getShape(lane)[1]
                nodes['from' + lane][1].append('L' + lane)
                locationNodes['from' + lane]=traci.lane.getShape(lane)[0]
        # complete build nodes and junction edges
        for lane, links in laneLinks.items():
            if (lane[0] != ':'):
                for link in links:
                    distance = self.calculateDistance(locationNodes['to' + lane],locationNodes['from' + link[0]])
                    edges['J' + lane + link[0]] = ['to' + lane, 'from' + link[0], [], distance]
                    nodes['to' + lane][1].append('J' + lane + link[0])
                    nodes['from' + link[0]][0].append('J' + lane + link[0])
        #nodes = sorted(nodes.items(), reverse=True)
        '''for oldk,oldv in nodes.items():
            for newk,newv in nodes.items():
                if oldk!=newk:
                    x=oldk[0:-2]
                    y=newk[0:-2]
                    if x==y:
                        edges['J' + oldk + newk] = [oldk, newk, [], 5]
                        nodes[oldk][1].append('J' + oldk + newk)
                        nodes[newk][0].append('J' + oldk + newk)'''

        self.printGraph(edges,locationNodes)

        #build edges objects
        for k, v in edges.items():
            self.__edges[k]=Edge(k,v[0],v[1],v[2],v[3])

        # build nodes objects
        for k,v in nodes.items():
            self.__nodes[k]=Node(k,v[0],v[1])

    # buildGraph function
    def buildGraph(self, lanes, laneLinks):
        nodes = {}
        edges = {}
        locationNodes = {}
        # build empty nodes and lane edges
        for lane in lanes:
            edge=lane[0:-2]
            if (edge[0] != ':') and (edge not in edges.keys()):
                # node [name,[in edges],[out edegs]]
                nodes['from' + edge] = [[], []]
                nodes['to' + edge] = [[], []]
                # edge [name,from node,to node ,[vehicles in edge],length]
                edges['L' + edge] = ['from' + edge, 'to' + edge, [], traci.lane.getLength(lane)]
                nodes['to' + edge][0].append('L' + edge)
                locationNodes['to' + edge] = traci.lane.getShape(lane)[1]
                nodes['from' + edge][1].append('L' + edge)
                locationNodes['from' + edge] = traci.lane.getShape(lane)[0]


        # complete build nodes and junction edges
        for lane, links in laneLinks.items():
            edge1 = lane[0:-2]
            for link in links:
                edge2 = link[0][0:-2]
                if (edge1[0] != ':') and(edge2[0] != ':')and (('J' +edge1+edge2) not in edges.keys()):
                    distance = link[-1]
                    # edge [name,from node,to node ,[vehicles in edge],length]
                    edges['J' + edge1 + edge2] = ['to' + edge1, 'from' + edge2, [], distance]
                    # node [name,[in edges],[out edegs]]
                    nodes['to' + edge1][1].append('J' + edge1 + edge2)
                    nodes['from' + edge2][0].append('J' + edge1 + edge2)



        #self.printGraph(edges,locationNodes)

        # build edges objects
        for k, v in edges.items():
            self.__edges[k] = Edge(k, v[0], v[1], v[2], v[3])

        # build nodes objects
        for k, v in nodes.items():
            self.__nodes[k] = Node(k, v[0], v[1])
        print("blabla")

    def calculateDistance(self,p1,p2):
        distance = math.sqrt(((p1[0] - p2[0]) ** 2) + ((p1[1] - p2[1]) ** 2))
        return distance

    def getEdge(self,edgeName):
        return self.__edges[edgeName]

    def getNode(self,nodeName):
        return self.__nodes[nodeName]

    def getNeighbors(self,edgeName):
        # edge [name,from node,to node ,[vehicles in edge],length]
        node=self.getNode(self.__edges[edgeName].getToNode())
        # node [name,[in edges],[out edegs]]
        return node.getOutEdges()

    def getReverseNeighbors(self,edgeName):
        # edge [name,from node,to node ,[vehicles in edge],length]
        node=self.getNode(self.__edges[edgeName].getFromNode())
        # node [name,[in edges],[out edegs]]
        return node.getInEdges()

    def getSiblingsNeighborsFrom(self,edgeName):
        # edge [name,from node,to node ,[vehicles in edge],length]
        node=self.getNode(self.__edges[edgeName].getFromNode())
        # node [name,[in edges],[out edegs]]
        x=[]
        for e in node.getOutEdges():
            if e!=edgeName:
                x.append(e)
        return x

    def getSiblingsNeighborsTo(self,edgeName):
        # edge [name,from node,to node ,[vehicles in edge],length]
        node=self.getNode(self.__edges[edgeName].getToNode())
        # node [name,[in edges],[out edegs]]
        x=[]
        for e in node.getOutEdges():
            if e!=edgeName:
                x.append(e)
        return x

    '''def getPath(self,e1,e2):
        #path from e1 to e2
        e1Neighbors=self.getNeighbors(e1.getName()).copy()
        e1Siblings=self.getSiblingsNeighborsFrom(e1.getName()).copy()
        e1Neighbors=list(set(e1Neighbors)-set(e1Siblings))
        e1Siblings = self.getSiblingsNeighborsTo(e1.getName()).copy()
        e1Neighbors = list(set(e1Neighbors) - set(e1Siblings))
        if e1Neighbors==[]:
            return None
        else:
            for n in  e1Neighbors:
                if n==e2.getName():
                    return e2
                else:
                    e1=self.getEdge(n)
                    x=self.getPath(e1,e2)
                    if x!=None:
                        return e1,x'''

    '''def getDistanceBetweenTwoVehicles(self,v1,v2):
        edge1=self.__edges[v1.getEdgeName()]
        edge2 = self.__edges[v2.getEdgeName()]
        if edge1==edge2:
            return abs(v1.getDistance()-v2.getDistance())
        else:
            #assume there is path between them
            path=self.getPath(edge1,edge2)
            distance=0.0
            if path==None:
                # path from e2 to e1
                path = self.getPath(edge2, edge1)
                if path==None:
                    return math.inf
                for e in path:
                    distance =distance+e.getLenght()
                distance = distance + (edge2.getLenght() - v2.getDistance())
                distance = distance - (edge1.getLenght() - v1.getDistance())
            else:
                # path from e1 to e2
                for e in path:
                    distance =distance+e.getLenght()
                distance=distance+(edge1.getLenght()-v1.getDistance())
                distance = distance - (edge2.getLenght() - v2.getDistance())

            return distance'''

    '''def getDistanceBetweenTwoVehicles(self, v1, v2,path):
    #v1 behind v2
    edge1 = self.__edges[v1.getEdgeName()]
    edge2 = self.__edges[v2.getEdgeName()]
    if path==[]:
        return abs(v2.getDistance() - v1.getDistance())
    else:
        # assume there is path between v1 to v2
        distance = 0.0
        for e in path:
            distance += e.getLenght()
        return abs(distance-edge2.getLenght()-v1.getDistance()+v2.getDistance())'''

    def getDistancePath(self, path):
        d=0.0
        if len(path)>=1:
            path=path[1:]
        for e in path:
            d=d+e.getLenght()
        return d

    def getDistanceBetweenTwoVehicles(self, v1, v2, path):
        # v1 behind v2
        d=self.getDistancePath(path)
        d1=v1.getDistance()
        d2=v2.getDistance()
        return abs(d-d1+d2)
    '''def getDistanceBetweenTwoVehicles(self, v1, v2,path):
        #v1 behind v2
        p1=v1.getPosition()
        p2=v2.getPosition()
        return self.calculateDistance(p1,p2)'''

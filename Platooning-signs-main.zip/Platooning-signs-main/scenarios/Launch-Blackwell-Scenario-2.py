import os
import sys
import logging
import traci
import time
sys.path.append(os.path.dirname(os.path.dirname(os.path.realpath(__file__))))
from src.simulationmanager import SimulationManager
from src.menu import Menue
from src.simlib import setUpSimulation
import matplotlib.pyplot as plt



def paint(X,Y,Z):
    '''fig = plt.figure(figsize=plt.figaspect(1))
maxX=max(X)
maxY=max(Y)
ax = fig.add_subplot(1, 2, 2, projection='3d')

    x = np.arange(len(X))
    y = np.arange(len(Y))
    x,y = np.meshgrid(x,y)
    z = np.zeros((len(X),len(Y)))

    fig, ax = plt.subplots(nrows=2, ncols=2, subplot_kw={'projection': '3d'})
    ax[0, 0].plot_wireframe(x, y, z, rstride=40, cstride=40)
    ax[0, 1].plot_surface(x, y, z, rstride=40, cstride=40, color='m')
    ax[1, 0].plot_surface(x, y, z, rstride=12, cstride=12, color='m')
    ax[1, 1].plot_surface(x, y, z, rstride=20, cstride=20, cmap=cm.hot)
    for axes in ax.flatten():
        axes.set_xticks([0, 30, 60, 90, 120])
        axes.set_yticks([0, 1, 2, 3])
        axes.set_zticks([0, 0.0025, 0.05])
    fig.tight_layout()
    plt.show()

    
    for i in range(len(Z)):
        for j in range(len(Z)):
            z[Y[i]][X[j]] = Z[i]
    ax.plot_wireframe(x,y,z, rstride=10, cstride=10)

    x = np.arange(len(X))
    y = np.arange(len(Y))
    x, y = np.meshgrid(x, y)
    z = np.zeros((len(X), len(Y)))
    #ax.plot_wireframe(x, y, z, rstride=10, cstride=10)
    arr1 = np.arange(maxX + 1)
    arr2 = np.arange(maxY + 1)
    arr1, arr2 = np.meshgrid(arr1, arr2)
    mat = np.zeros((maxY+1,maxX+1))

    for i in range(len(Z)):
        #for j in range(len(Z)):
        mat[Y[i]][X[i]]=Z[i]
    ax.plot_wireframe(arr1, arr2, mat, rstride=10, cstride=10)
    plt.show() '''

    x0 = []
    y0 = []
    z0 = []
    x1 = []
    x2 = []
    x3 = []
    y1 = []
    y2 = []
    y3 = []
    z1 = []
    z2 = []
    z3 = []
    for i  in range(len(Y)):
        if Y[i]==0:
            x0.append(X[i])
            y0.append(Y[i])
            z0.append(Z[i])
        elif Y[i]==1:
            x1.append(X[i])
            y1.append(Y[i])
            z1.append(Z[i])
        elif Y[i]==2:
            x2.append(X[i])
            y2.append(Y[i])
            z2.append(Z[i])
        else:
            x3.append(X[i])
            y3.append(Y[i])
            z3.append(Z[i])
    fig, ax = plt.subplots()
    ax.plot(x0, z0, 'r-',x1, z1, 'g-',x2, z2, 'k-',x3,z3,'b-')
    plt.show()



setUpSimulation("../maps/BlackwellTunnelNorthApproach/BlackwellTunnelNorthApproach.sumocfg", 1)
step = 0
manager = SimulationManager()
menu=Menue()
maxNumAtTrafficLights = 0

x=[]
y=[]
z=[]


while step < 5000:
    start_step = time.time()
    manager.handleSimulationStep()
    traci.simulationStep()
    menu.run(manager)


    '''step += 1

    if step == 500:
        i = 'MainA12South.10'
        manager.addPlatoon(i)
        i = 'RoundInA12South.2'
        manager.addPlatoon(i)
    if step==720:
        i = 'MainA12South.20'
        manager.addPlatoon(i)
    if step==514:
        i = 'RoundInA12South.4'
        manager.addPlatoon(i)
    if step==553:
        print("stop")
        RoundInA13.0 '''

    duration = time.time()-start_step
    countOfVehicles=len(traci.vehicle.getIDList())
    countOfPlatoons=manager.CountOfPlatoons()
    '''x.append(countOfVehicles)
    y.append(countOfPlatoons)
    z.append(duration)
    if step==2000:
        paint(x,y,z)
    '''
    #print("countOfVehicles:"+str(countOfVehicles)+"   countOfPlatoons:"+str(countOfPlatoons)+"  timeCalculation:"+str(duration))


logging.info("Max number of stopped cars: %s", manager.maxStoppedVehicles)
logging.info("Average length of platoon: %s", manager.getAverageLengthOfAllPlatoons())
traci.close()

